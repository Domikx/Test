# StockX Receip Generator


<p align="center">
  <a href="https://youtu.be/ut8Yj_lU9J8?si=FuhXKSF-XgFgzQFt">
    <img src="https://cdn.discordapp.com/attachments/1086987915642552410/1313593937935466687/maisonv2.png?ex=67515bf0&is=67500a70&hm=e615cee33e93787a8ebaf23cbdded40f2064615d35eb60813081bd0bd4dd9912&" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">[Receipt Generator] - Maison</h3>

  <p align="center">
    This is a discord bot that generates receipts for StockX, Goat, Apple and more. This is the perfect thing to make reselling more safe.
    Join our discord to see what generators we got and what you can do. Trust me it is worth it.
    <br/>
    <br/>
    <a href="https://discord.gg/maison">Discord</a>
    ・
    <a href="https://youtu.be/ut8Yj_lU9J8?si=FuhXKSF-XgFgzQFt">Showcase</a>
    ・
    <a href="https://maisonreceipts.cc">Website</a>
  </p>
</p>

<p align="center">
  <img alt="preview" src="https://cdn.discordapp.com/attachments/1086987915642552410/1313979134187278336/Frame22.png?ex=675219ee&is=6750c86e&hm=37b67ae886a765e5975c720477b715256e1f51d5f9e0b565c1edf5746ac36087&">
</p>




